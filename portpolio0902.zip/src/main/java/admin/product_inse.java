package admin;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Enumeration;

import javax.servlet.ServletException;
import javax.servlet.annotation.MultipartConfig;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/admin/product_inse")
//@MultipartConfig(
//		maxFileSize=1024*1024*2,
//		location="c:\\upload"
//		)
public class product_inse extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    public product_inse() {
    }

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		request.setCharacterEncoding("UTF-8");
    	response.setContentType("text/html; charset=UTF-8");
    	PrintWriter out = response.getWriter();
    	
    	ArrayList<String> al = new ArrayList<String>();
    	Enumeration em = request.getParameterNames();
    	category_sql cs = new category_sql();
    	ArrayList<category_sql> cateck = null;
    	boolean xx = true;
    	while(em.hasMoreElements()) {
    		String a = (String)em.nextElement();
    		String b = request.getParameter(a);
    		if(a.equals("plarge_cate")) {
    			if(cs.select("lck",b,"","").size()==0) {
    				xx = false;
    			}
    		}
    		if(a.equals("psmall_cate")) {
    			if(cs.select("sck",b,"","").size()==0) {
    				xx = false;
    			}
    		}
    		if(a.equals("pimg1")||a.equals("pimg2")||a.equals("pimg3")) {
    			if(b==null || b.equals("")) {
    				b = "nofile";
    			}
    		}
    		al.add(b);
    	}
    	System.out.println(al);
    	product_sql ps = new product_sql();
    	if(xx) {
	    	if(ps.insert(al, "")) {
	    		out.print("<script>alert('등록성공');location.href='admin_product';</script>");
	    	}
	    	else {
	    		out.print("<script>alert('등록실패');history.go(-1);</script>");
	    	}
	    }
    	else {
    		out.print("<script>alert('카테고리 등록을 해주세요');history.go(-1);</script>");
    	}
    	
	}

}
